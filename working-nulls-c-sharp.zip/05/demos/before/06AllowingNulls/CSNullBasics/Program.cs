﻿using System;

namespace CSNullBasics
{
    class Program
    {
        static void Main()
        {

            string message = null;


            Console.WriteLine(message);

            Console.WriteLine("Press enter to end.");
            Console.ReadLine();
        }
    }
}
