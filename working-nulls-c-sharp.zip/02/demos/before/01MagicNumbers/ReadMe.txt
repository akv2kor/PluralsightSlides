There is no before demo code here because in the video we create a new console application from scratch.

You can find the after solution with the console application created in this module's after\01MagicNumbers folder.