﻿namespace GameConsole
{
    public class DiamondSkinDefence : SpecialDefence
    {
        public override int CalculateDamageReduction() => 1;
    }
}