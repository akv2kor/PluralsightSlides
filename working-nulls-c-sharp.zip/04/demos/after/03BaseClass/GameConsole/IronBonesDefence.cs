﻿namespace GameConsole
{
    public class IronBonesDefence : SpecialDefence
    {
        public override int CalculateDamageReduction() => 5;
    }
}
