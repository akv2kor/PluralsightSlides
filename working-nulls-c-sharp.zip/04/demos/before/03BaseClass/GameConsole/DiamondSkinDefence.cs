﻿namespace GameConsole
{
    public class DiamondSkinDefence : ISpecialDefence
    {
        public int CalculateDamageReduction() => 1;
    }
}