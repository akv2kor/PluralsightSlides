﻿namespace GameConsole
{
    public interface ISpecialDefence
    {
        int CalculateDamageReduction();
    }
}