﻿namespace GameConsole
{
    public class IronBonesDefence : ISpecialDefence
    {
        public int CalculateDamageReduction() => 5;
    }
}
